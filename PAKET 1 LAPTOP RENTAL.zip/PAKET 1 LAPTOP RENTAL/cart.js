let cart = JSON.parse(localStorage.getItem('cart')) || [];

function addToCart(product) {
    if (!product.status) {
        alert("Laptop ini tidak tersedia untuk disewa.");
        return;
    }

    const existingItem = cart.find(item => item.laptopName === product.laptopName);
    if (existingItem) {
        alert("Laptop ini sudah ada di cart anda.");
        return;
    }

    cart.push(product);
    localStorage.setItem('cart', JSON.stringify(cart)); 
    alert(`${product.laptopName} telah ditambahkan dalam cart.`);
    updateCartDisplay();
}


function updateCartDisplay() {
    const cartDiv = document.getElementById('cartItems');
    cartDiv.innerHTML = ''; 

    let totalPrice = 0;

    cart.forEach(item => {
        const itemDiv = document.createElement('div');
        itemDiv.innerHTML = `
            <p>${item.laptopName} - Rp${item.rentPrice.toLocaleString()}</p>
            <button onclick="removeFromCart('${item.laptopName}')">Remove</button>
        `;
        cartDiv.appendChild(itemDiv);
        totalPrice += item.rentPrice;
    });

    const totalDiv = document.getElementById('totalPrice');
    totalDiv.innerHTML = `Total: Rp${totalPrice.toLocaleString()}`;
}


function removeFromCart(productName) {
    cart = cart.filter(item => item.laptopName !== productName);
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartDisplay();
}


function checkout() {
    if (cart.length === 0) {
        alert("Cart anda kosong.");
        return;
    }

    alert("Terimakasih telah menyewa!");
    cart = []; 
    localStorage.removeItem('cart'); 
    updateCartDisplay();
}
function goBack() {
    window.history.back(); 
}
document.addEventListener('DOMContentLoaded', updateCartDisplay);
