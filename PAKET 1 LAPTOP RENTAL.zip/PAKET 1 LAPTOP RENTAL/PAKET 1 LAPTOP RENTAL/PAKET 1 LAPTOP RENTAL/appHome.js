const laptopList = [
  {
    laptopName: "Lenovo Laptop",
    brand: "Lenovo",
    rentPrice: 50000,
    rating: 3,
    status: true,
    imageUrl: "images/Lenovo Laptop.jpg",
  },
  {
    laptopName: "Huawei Matebook",
    brand: "Huawei",
    rentPrice: 200000,
    rating: 4,
    status: true,
    imageUrl: "images/Huawei Laptop.jpg",
  },
  {
    laptopName: "Dell Laptop",
    brand: "Dell",
    rentPrice: 100000,
    rating: 3,
    status: true,
    imageUrl: "images/DELL Laptop.jpg",
  },
  {
    laptopName: "Asus Chromebook",
    brand: "Asus",
    rentPrice: 25000,
    rating: 5,
    status: true,
    imageUrl: "images/Asus Chromebook Laptop.jpg",
  },
  {
    laptopName: "Alienware Laptop",
    brand: "Dell",
    rentPrice: 300000,
    rating: 4,
    status: false,
    imageUrl: "images/Alienware Laptop.jpg",
  },
  {
    laptopName: "Lenovo Yoga",
    brand: "Lenovo",
    rentPrice: 300000,
    rating: 2,
    status: true,
    imageUrl: "images/Lenovo Yoga Duet Laptop.jpg",
  },
  {
    laptopName: "ROG Strix",
    brand: "Asus",
    rentPrice: 250000,
    rating: 3,
    status: true,
    imageUrl: "images/ROG Laptop.jpg",
  },
  {
    laptopName: "MSI Laptop",
    brand: "MSI",
    rentPrice: 300000,
    rating: 3,
    status: false,
    imageUrl: "images/MSI Laptop.jpg",
  },
  {
    laptopName: "Asus Zenbook",
    brand: "Asus",
    rentPrice: 400000,
    rating: 2,
    status: true,
    imageUrl: "images/Zenbook Laptop.jpg",
  },
  {
    laptopName: "ROG Zephyrus",
    brand: "Asus",
    rentPrice: 200000,
    rating: 5,
    status: true,
    imageUrl: "images/ROG Zephyrus Laptop.jpg",
  },
];

function productList(productToDisplay) {
  const productListDiv = document.getElementById("productList");
  productListDiv.innerHTML = "";

  if (productToDisplay.length === 0) {
    productListDiv.innerHTML = "<p>No products found.</p>";
    return;
  }

  productToDisplay.forEach((product) => {
    const productItem = document.createElement("div");
    productItem.classList.add("product-item");

    productItem.setAttribute(
      "onclick",
      `openProductPage('${product.laptopName}')`
    );
    // productItem.setAttribute("onmouseover", "bigger(this)");

    productItem.innerHTML = `
            <img class="besar" src="${product.imageUrl}" alt="${product.laptopName}">
            <h3>${product.laptopName}</h3>
            <p>Brand: ${product.brand}</p>
            <p>Price: Rp${product.rentPrice.toLocaleString()}</p>
            <p>Rating: ${"⭐".repeat(product.rating)}</p>
            <p>Status: <span class="${product.status ? "" : "unavailable"}">${product.status ? "Available" : "Not Available"
      }</span></p>
        `;

    productListDiv.appendChild(productItem);
    // productItem.addEventListener("mouseover", () => document.querySelector(".besar").setAttribute("style", "transform : scale(1.2);"))
  });
}

function openProductPage(productName) {
  window.location.href = `productDetails.html?product=${encodeURIComponent(
    productName
  )}`;
}

function filterProducts() {
  const searchInput = document.getElementById("search").value.toLowerCase();
  const brandFilter = document.getElementById("brandFilter").value;

  const filteredProducts = laptopList.filter((product) => {
    const matchesSearch = product.laptopName
      .toLowerCase()
      .includes(searchInput);
    const matchesBrand = brandFilter
      ? product.brand.toLowerCase() === brandFilter.toLowerCase()
      : true;
    return matchesSearch && matchesBrand;
  });

  const sortedFilteredProducts = sortProducts(filteredProducts);
  productList(sortedFilteredProducts);
}

function sortProducts(productsToSort) {
  const sortOption = document.getElementById("sortOptions").value;

  if (sortOption === "name") {
    return productsToSort.sort((a, b) =>
      a.laptopName.localeCompare(b.laptopName)
    );
  } else if (sortOption === "priceLow") {
    return productsToSort.sort((a, b) => a.rentPrice - b.rentPrice);
  } else if (sortOption === "priceHigh") {
    return productsToSort.sort((a, b) => b.rentPrice - a.rentPrice);
  } else if (sortOption === "popular") {
    return productsToSort.filter((product) => product.rating === 5);
  } else if (sortOption === "onlyAvailable") {
    return productsToSort.filter((product) => product.status);
  } else if (sortOption === "onlyUnavailable") {
    return productsToSort.filter((product) => !product.status);
  }

  return productsToSort;
}

function updateCartCount() {
  const cartItems = JSON.parse(localStorage.getItem("cart")) || [];
  document.getElementById("cart-count").innerText = cartItems.length;
}

window.onload = function () {
  filterProducts(); // Display all products initially
  updateCartCount(); // Update cart count on load
};

// const kartu = document.querySelector("#productList");

// kartu.addEventListener("mouseover", () => document.getElementsByClassName("besar").style.width = "20px")
// // function bigger(tll){
// //     console.log(dongo)
// //     dongo.style.transform = "scale(2)"
// //     console.log(tll)
// //     // dongo.style.transform = "scale(2)";
// // }

// kartu.addEventListener("mouseover", () => document.querySelector(".besar").setAttribute("style", "transform : scale(2)"))

// rekom
const carousel = document.querySelector(".carousel");
const slides = document.querySelectorAll(".slide");
const controlLinks = document.querySelectorAll(".controls a");
const classNamaLaptop = document.getElementById("classNamaLaptop");
const classDescLaptop = document.getElementById("classDescLaptop");

let i = 0,
  j = 1,
  intervalid;

const backgrounds = [
  "images/rekomen/bg/ROG-bg.jpeg",
  "images/rekomen/bg/Huawei-bg.jpeg",
  "images/rekomen/bg/Chromebook-bg.jpeg",
  "images/rekomen/bg/ALIENWARE-bg.jpeg",
];

function setBackground(image) {
  document.getElementById("slideshow").style.backgroundImage = `url(${image})`;
}
const slideshow = document.getElementById("slideshow");

const intervalFn = () => {
  intervalid = setInterval(() => {
    carousel.style.rotate = `-${++i * 90}deg`;
    
    const currentSlide = document.querySelector(".slide.active");
    currentSlide.classList.remove("active");
    
    const activeSlide = document.querySelector(`.slide:nth-child(${++j})`);
    activeSlide.classList.add("active");

    if (j === 1) {
      slideshow.style.backgroundImage = `url(${backgrounds[0]})`;
      classNamaLaptop.innerHTML = laptopList[9].laptopName;
      classDescLaptop.innerHTML = `Dinamis dan siap bepergian, Laptop pionir ROG Zephyrus G14 adalah laptop gaming 14 inci berbasis Microsoft Windows 10 Home terkuat. Mengungguli persaingan dengan prosesor hingga 8-core AMD Ryzen™ 9 4900HS series CPU dan GeForce RTX™ 2060 GPU yang kuat yang mempercepat melalui multitasking dan game sehari-hari.
      <br><br><br>
      <p>Rating: ${"⭐".repeat(laptopList[9].rating)} Price: Rp${laptopList[9].rentPrice.toLocaleString()}</p>`;
    } else if (j === 2) {
      slideshow.style.backgroundImage = `url(${backgrounds[1]})`;
      classNamaLaptop.innerHTML = laptopList[1].laptopName;
      classDescLaptop.innerHTML = `Nikmati setiap tampilan HUAWEI MateBook D 14 berkat IPS anti-glare 14" HUAWEI FullView Display1 dan rasio aspek 16:9. Dengan resolusi Full-HD 1920 x 1080, setiap gambar dipenuhi detail dan kejelasan untuk pengalaman menonton yang lebih baik setiap kalinya
      <br><br><br>
      <p>Rating: ${"⭐".repeat(laptopList[1].rating)} Price: Rp${laptopList[1].rentPrice.toLocaleString()}</p>`;
    } else if (j === 3) {
      slideshow.style.backgroundImage = `url(${backgrounds[2]})`;
      classNamaLaptop.innerHTML = laptopList[3].laptopName;
      classDescLaptop.innerHTML = `Perangkat ASUS Chrome OS Enterprise dirancang untuk memastikan setiap bisnis dilengkapi untuk berhasil. Menjalankan Chrome OS yang tangguh, perangkat tangguh ini memudahkan pekerja untuk mempercepat melalui setiap tugas – dan untuk memanfaatkan teknologi cloud sebaik-baiknya.
      <br><br><br>
      <p>Rating: ${"⭐".repeat(laptopList[3].rating)} Price: Rp${laptopList[3].rentPrice.toLocaleString()}</p>`;
    } else if (j === 4) {
      slideshow.style.backgroundImage = `url(${backgrounds[3]})`;
      classNamaLaptop.innerHTML = laptopList[4].laptopName;
      classDescLaptop.innerHTML = `Buat profil performa yang ditujukan untuk daya, manajemen termal, suara, pencahayaan, makro, dan lainnya di Alienware Command Center untuk pengalaman bermain game terbaik. Versi terbaru mencakup pengaturan AlienFX yang mudah disesuaikan, opsi overclocking yang intuitif, dan mode manajemen daya yang unik berdasarkan preferensi pribadi Anda.
      <br><br>
      <p>Rating: ${"⭐".repeat(laptopList[4].rating)} Price: Rp${laptopList[4].rentPrice.toLocaleString()}</p>`;
    }
    
    
    //   const slideText = activeSlide.querySelector('.slide-text');
    //   const textDisplay = document.getElementById('slideText');
    //   textDisplay.textContent = slideText.getAttribute('data-text');
    //  console.log(slideText)
    
    if (j === 4) {
      j = 0;
    }
  }, 2000);
};
// const slideTextContainer = document.createElement('div');
// slideTextContainer.id = 'slideText';
// document.getElementById('slideshow').appendChild(slideTextContainer);
intervalFn();

controlLinks.forEach((control) => {
  control.addEventListener("click", () => {
    const index = Number(control.dataset.index);

    if (control.classList.contains("active")) {
      control.style.backgroundColor = ""; 
      control.classList.remove("active");
      intervalFn();
      return; 
    }else{
      clearInterval(intervalid)
    }

     
    carousel.style.rotate = `-${(i - j + Number(control.dataset.index)) * 90}deg`;

    document.querySelector(".slide.active").classList.remove("active");
    const activeSlide = document.querySelector(`.slide:nth-child(${index})`);
    activeSlide.classList.add("active");

    if (index === 1) {
      slideshow.style.backgroundImage = `url(${backgrounds[0]})`;
      classNamaLaptop.innerHTML = laptopList[9].laptopName;
      // classNamaLaptop.innerHTML = laptops.rogZephyrus.name;
      classDescLaptop.innerHTML = `Dinamis dan siap bepergian, Laptop pionir ROG Zephyrus G14 adalah laptop gaming 14 inci berbasis Microsoft Windows 10 Home terkuat. Mengungguli persaingan dengan prosesor hingga 8-core AMD Ryzen™ 9 4900HS series CPU dan GeForce RTX™ 2060 GPU yang kuat yang mempercepat melalui multitasking dan game sehari-hari.
      <br><br><br>
      <p>Rating: ${"⭐".repeat(laptopList[9].rating)} Price: Rp${laptopList[9].rentPrice.toLocaleString()}</p>`;
    } else if (index === 2) {
      slideshow.style.backgroundImage = `url(${backgrounds[1]})`;
      classNamaLaptop.innerHTML = laptopList[1].laptopName;
      classDescLaptop.innerHTML = `Nikmati setiap tampilan HUAWEI MateBook D 14 berkat IPS anti-glare 14" HUAWEI FullView Display1 dan rasio aspek 16:9. Dengan resolusi Full-HD 1920 x 1080, setiap gambar dipenuhi detail dan kejelasan untuk pengalaman menonton yang lebih baik setiap kalinya
      <br><br><br>
      <p>Rating: ${"⭐".repeat(laptopList[1].rating)} Price: Rp${laptopList[1].rentPrice.toLocaleString()}</p>`;
    } else if (index === 3) {
      slideshow.style.backgroundImage = `url(${backgrounds[2]})`;
      classNamaLaptop.innerHTML = laptopList[3].laptopName;
      classDescLaptop.innerHTML = `Perangkat ASUS Chrome OS Enterprise dirancang untuk memastikan setiap bisnis dilengkapi untuk berhasil. Menjalankan Chrome OS yang tangguh, perangkat tangguh ini memudahkan pekerja untuk mempercepat melalui setiap tugas – dan untuk memanfaatkan teknologi cloud sebaik-baiknya.
      <br><br><br>
      <p>Rating: ${"⭐".repeat(laptopList[3].rating)} Price: Rp${laptopList[3].rentPrice.toLocaleString()}</p>`;
    } else if (index === 4) {
      slideshow.style.backgroundImage = `url(${backgrounds[3]})`;
      classNamaLaptop.innerHTML = laptopList[4].laptopName;    
      classDescLaptop.innerHTML = `Buat profil performa yang ditujukan untuk daya, manajemen termal, suara, pencahayaan, makro, dan lainnya di Alienware Command Center untuk pengalaman bermain game terbaik. Versi terbaru mencakup pengaturan AlienFX yang mudah disesuaikan, opsi overclocking yang intuitif, dan mode manajemen daya yang unik berdasarkan preferensi pribadi Anda.
      <br><br>
      <p>Rating: ${"⭐".repeat(laptopList[4].rating)} Price: Rp${laptopList[4].rentPrice.toLocaleString()}</p>`;
    }

    controlLinks.forEach(link => {
      link.classList.remove("active");
      link.style.backgroundColor = ""; 
    });
    control.classList.add("active");
    control.style.backgroundColor = ""; 
  });
});

carousel.addEventListener("mouseenter", () => {
  clearInterval(intervalid);
})
carousel.addEventListener("mouseleave", () => {
  intervalFn();
});


const bg1 = document.querySelector(".poto1")
const bg2 = document.querySelector(".poto2")
const bg3 = document.querySelector(".poto3")
const bg4 = document.querySelector(".poto4")

// if (bg3.classList.contains("active")) {
//   slideshow.style.backgroundImage = `url(${backgrounds[3]})`;
//   console.log(bg1)
// }
